<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminsTableSeeder extends Seeder
{
    /**
     * Run the seeder.
     *
     * @return void
     */
    public function run()
    {
        // Insert a new admin user
        DB::table('admins')->insert([
            'name' => 'Admin User',
            'email' => 'admin@cargoconvoy.co',
            'password' => Hash::make('admin@#123'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
